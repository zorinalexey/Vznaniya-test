//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by fat12_rc.rc
//
#define IDI_FAT12                       0x1000
#define IDS_FAT12_NAME                  0x1000
#define IDS_FAT12_NICKNAME              0x1001
//#define IDS_FAT12_DETAIL_NAME           0x1002
#define IDS_GROUP_NICKNAME              0x1004
#define IDS_GROUP_NAME                  0x1005
#define IDS_FAT12_INSERT_TEXT           0x1300
#define IDS_FAT12_CARRIER_TYPE          0x1302
#define IDI_HDIMAGE                     0x2000
#define IDS_HDIMAGE_NAME                0x2000
#define IDS_HDIMAGE_NICKNAME            0x2001
#define IDS_HDIMAGE_DETAIL_NAME         0x2002
#define IDS_HDIMAGE_INSERT_TEXT         0x2300
#define IDS_HDIMAGE_CARRIER_TYPE        0x2302
#define IDI_EHDIMAGE                    0x3000
#define IDS_EHDIMAGE_NAME               0x3000
#define IDS_EHDIMAGE_NICKNAME           0x3001
#define IDS_EHDIMAGE_DETAIL_NAME        0x3002
#define IDS_EHDIMAGE_INSERT_TEXT        0x3300
#define IDS_EHDIMAGE_CARRIER_TYPE       0x3302
#define IDI_DEFAULT                     0x4000
#define IDS_DEFAULT_NAME                0x4000
#define IDS_DEFAULT_NICKNAME            0x4001
#define IDS_DEFAULT_DETAIL_NAME         0x4002
#define IDS_DEFAULT_INSERT_TEXT         0x4300
#define IDS_DEFAULT_CARRIER_TYPE        0x4302
#define IDS_HDIMAGE_INFO                0x4303
#define IDS_EHDIMAGE_INFO               0x4304
#define IDS_FAT12_INFO                  0x4305

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NO_MFC                     1
#define _APS_NEXT_RESOURCE_VALUE        102
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif

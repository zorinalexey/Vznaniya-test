//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by rndm0_rc.rc
//
#define IDI_RNDM0                       4096
#define IDS_RNDM0_NAME                  0x1000
#define IDS_RNDM0_NICKNAME              0x1001
#define IDS_RNDM0_DETAIL_NAME           0x1002
#define IDS_FAPSI0_NAME                 0x2000
#define IDS_FAPSI0_NICKNAME             0x2001
#define IDS_FAPSI0_DETAIL_NAME          0x2002

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        102
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
